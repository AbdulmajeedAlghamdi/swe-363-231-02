// Exercise-3
const express = require('express');
const router = express.Router();

router.get('/page1', (req, res) => {
  res.send('This is page1');
});

router.get('/page2', (req, res) => {
  res.send('This is page2');
});

router.get('/page3', (req, res) => {
  res.send('This is page3');
});

module.exports = router;