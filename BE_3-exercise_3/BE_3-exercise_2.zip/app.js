// Exercise-2
const express = require('express');
const app = express();
const port = 3333;
app.get('/page1', (req, res) => {
  res.send('This is page1');
});

app.get('/page2', (req, res) => {
  res.send('This is page2');
});

app.get('/page3', (req, res) => {
  res.send('This is page3');
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
