// Exercise-4
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3333;

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(__dirname));

const router = require('./router');
app.use(router);

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
